package com.dstuido.lnutcmlai;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
