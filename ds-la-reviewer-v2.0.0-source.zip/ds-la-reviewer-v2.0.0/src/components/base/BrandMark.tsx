import { useId } from 'react'

/**
 * 品牌图形：蓝色渐变圆角方块 + 展开的教材。
 * 只使用抽象几何；用于侧栏、顶栏和 API 接入页。
 */
export const BrandMark = ({ size = 28 }: { size?: number }) => {
  const id = useId().replace(/:/g, '')
  return (
    <svg
      className="brand-mark"
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={`${id}-bg`} x1="2" y1="1" x2="30" y2="31">
          <stop stopColor="#7C9CFF" />
          <stop offset="0.55" stopColor="#4D6BFE" />
          <stop offset="1" stopColor="#2947D8" />
        </linearGradient>
        <linearGradient id={`${id}-paper`} x1="8" y1="9" x2="24" y2="24">
          <stop stopColor="#FFFFFF" />
          <stop offset="1" stopColor="#E7EEFF" />
        </linearGradient>
      </defs>
      <rect x="1" y="1" width="30" height="30" rx="9" fill={`url(#${id}-bg)`} />
      <path
        d="M7.8 9.6c3.1-.9 6.2-.7 8.2 1 2-1.7 5.1-1.9 8.2-1v13.1c-3.1-.9-6.2-.7-8.2 1-2-1.7-5.1-1.9-8.2-1V9.6Z"
        fill={`url(#${id}-paper)`}
      />
      <path
        d="M16 10.6v13.1"
        stroke="#2947D8"
        strokeOpacity="0.5"
        strokeWidth="1.25"
        strokeLinecap="round"
      />
      <path
        d="M10.2 12.6c1.7-.2 3.1.1 4.2.8M10.2 15.4c1.7-.2 3.1.1 4.2.8M17.8 12.6c1.7-.2 3.1.1 4.2.8"
        stroke="#6D86E8"
        strokeWidth="0.9"
        strokeLinecap="round"
      />
      <circle cx="23.4" cy="9.2" r="1.9" fill="#FFFFFF" fillOpacity="0.92" />
    </svg>
  )
}
