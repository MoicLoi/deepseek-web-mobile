import clsx from 'clsx'
import type { CSSProperties } from 'react'
import { contextRoundsLabel } from './contextRoundsLabel.js'
import { useTranslate } from '../../i18n/index.js'
import {
  CONTEXT_ROUND_OPTIONS,
  setContextRounds,
  useSettings,
} from '../../services/settings.js'
import { MODE_IDS, MODE_PRESETS, type ModeId } from '../../services/modes.js'
import { Button } from '../base/Button.js'
import { Modal } from '../base/Modal.js'
import { Select } from '../base/Select.js'
import { openSettings } from '../settings/settingsDialogState.js'
import { ModeIcon } from './ModeIcon.js'
import styles from './ModePicker.module.css'

export const ModePicker = ({
  open,
  mode,
  onSelect,
  onClose,
}: {
  open: boolean
  mode: ModeId
  onSelect: (mode: ModeId) => void
  onClose: () => void
}) => {
  const t = useTranslate()
  const contextRounds = useSettings((state) => state.contextRounds)

  if (!open) {
    return null
  }

  return (
    <Modal
      title={t('modePickerTitle')}
      closable
      className={styles.dialog}
      mainClassName={styles.dialogMain}
      onClose={onClose}
      footer={
        <div className={styles.footer}>
          <button
            type="button"
            className={styles.promptLink}
            onClick={() => {
              onClose()
              openSettings('prompts')
            }}
          >
            {t('modePickerManagePrompts')}
          </button>
          <Button onClick={onClose}>{t('modeDone')}</Button>
        </div>
      }
    >
      <p className={styles.description}>{t('modePickerDescription')}</p>
      <div className={styles.grid} role="radiogroup" aria-label={t('modePickerTitle')}>
        {MODE_IDS.map((id) => {
          const preset = MODE_PRESETS[id]
          const selected = id === mode
          return (
            <button
              key={id}
              type="button"
              role="radio"
              aria-checked={selected}
              className={clsx(styles.card, selected && styles.selected)}
              style={{ '--mode-accent': preset.accent } as CSSProperties}
              onClick={() => onSelect(id)}
            >
              <span className={styles.icon}>
                <ModeIcon mode={id} size={20} />
              </span>
              <span className={styles.cardText}>
                <span className={styles.cardTitle}>{t(preset.labelKey)}</span>
                <span className={styles.cardDesc}>{t(preset.descriptionKey)}</span>
              </span>
              <span className={styles.radio} aria-hidden>
                {selected ? <span className={styles.radioDot} /> : null}
              </span>
            </button>
          )
        })}
      </div>
      <div className={styles.context}>
        <div className={styles.contextText}>
          <div className={styles.contextTitle}>{t('modePickerContext')}</div>
          <div className={styles.contextDesc}>{t('modePickerContextDescription')}</div>
        </div>
        <Select
          ariaLabel={t('modePickerContext')}
          value={String(contextRounds)}
          options={CONTEXT_ROUND_OPTIONS.map((value) => ({
            value: String(value),
            label: contextRoundsLabel(t, value),
          }))}
          onChange={(value) => setContextRounds(Number(value))}
        />
      </div>
    </Modal>
  )
}
