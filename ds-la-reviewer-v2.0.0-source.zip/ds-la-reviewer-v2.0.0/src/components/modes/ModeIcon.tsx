import type { ModeId } from '../../services/modes.js'

/** 模式图标的统一 18px 线性风格；颜色继承 currentColor。 */
export const ModeIcon = ({ mode, size = 18 }: { mode: ModeId; size?: number }) => {
  const common = {
    width: size,
    height: size,
    viewBox: '0 0 20 20',
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 1.5,
    strokeLinecap: 'round' as const,
    strokeLinejoin: 'round' as const,
    'aria-hidden': true,
  }
  switch (mode) {
    case 'reference':
      return (
        <svg {...common}>
          <path d="M3.3 4.8c2.5-.8 4.7-.6 6.7.8 2-1.4 4.2-1.6 6.7-.8v10.8c-2.5-.8-4.7-.6-6.7.8-2-1.4-4.2-1.6-6.7-.8V4.8Z" />
          <path d="M10 5.6v10.8M6 8.4c1.2-.2 2.2 0 3 .5M6 11.2c1.2-.2 2.2 0 3 .5" />
          <circle cx="14.7" cy="13.7" r="2.2" />
          <path d="m16.3 15.3 1.5 1.5" />
        </svg>
      )
    case 'quiz':
      return (
        <svg {...common}>
          <rect x="4" y="3.2" width="12" height="13.6" rx="2" />
          <path d="M7 7h6M7 10h6M7 13h3.5" />
          <path d="m14.6 12.1.9.9 1.8-2" />
        </svg>
      )
    case 'fragment':
      return (
        <svg {...common}>
          <path d="M4.2 16.2 5 12.8 13.2 4.6a1.7 1.7 0 0 1 2.4 2.4l-8.2 8.2-3.2.9Z" />
          <path d="m11.8 6 2.4 2.4M4.8 15.6l2.3-.6" />
        </svg>
      )
    case 'mock':
      return (
        <svg {...common}>
          <rect x="4.2" y="4" width="11.6" height="13" rx="2" />
          <path d="M7.4 4V2.8h5.2V4M7.2 8h5.6M7.2 11h5.6M7.2 14h3.4" />
          <circle cx="15.2" cy="15" r="2.4" />
          <path d="M15.2 13.8V15l.9.6" />
        </svg>
      )
  }
}
