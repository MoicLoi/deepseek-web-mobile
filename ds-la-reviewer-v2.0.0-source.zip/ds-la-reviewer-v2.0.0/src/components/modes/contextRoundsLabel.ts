import type { TranslationKey } from '../../i18n/index.js'

type Translate = (key: TranslationKey) => string

/** 把上下文轮数设置转成界面文案；0 表示不截断。 */
export const contextRoundsLabel = (t: Translate, value: number): string => {
  switch (value) {
    case 6:
      return t('contextRounds6')
    case 24:
      return t('contextRounds24')
    case 0:
      return t('contextRoundsAll')
    default:
      return t('contextRounds12')
  }
}
