import { useState, type CSSProperties } from 'react'
import clsx from 'clsx'
import { IconChevronDownOutline14 } from '../base/icons.js'
import { useTranslate } from '../../i18n/index.js'
import { getModePreset, type ModeId } from '../../services/modes.js'
import { setMode, useSettings } from '../../services/settings.js'
import { setSessionMode } from '../../services/chat/store.js'
import { ModeIcon } from './ModeIcon.js'
import { ModePicker } from './ModePicker.js'
import styles from './ModeBar.module.css'

/**
 * 输入框上方的模式条：显示当前模式与请求实际携带的上下文轮数。
 * 新对话改的是默认模式；已有会话把模式写回会话。
 */
export const ModeBar = ({
  mode,
  sessionId,
  className,
}: {
  mode: ModeId
  sessionId: string | null
  className?: string
}) => {
  const t = useTranslate()
  const [open, setOpen] = useState(false)
  const contextRounds = useSettings((state) => state.contextRounds)
  const preset = getModePreset(mode)
  const selectMode = (next: ModeId) => {
    if (sessionId) {
      setSessionMode(sessionId, next)
    } else {
      setMode(next)
    }
  }

  return (
    <div className={clsx(styles.bar, className)}>
      <button
        type="button"
        className={styles.modeButton}
        style={{ '--mode-accent': preset.accent } as CSSProperties}
        aria-haspopup="dialog"
        aria-expanded={open}
        onClick={() => setOpen(true)}
      >
        <span className={styles.icon}>
          <ModeIcon mode={mode} size={17} />
        </span>
        <span className={styles.label}>{t(preset.labelKey)}</span>
        <IconChevronDownOutline14 />
      </button>
      <span className={styles.context}>
        {contextRounds > 0 ? t('contextRoundsShort', { count: contextRounds }) : t('contextAll')}
      </span>
      <ModePicker
        open={open}
        mode={mode}
        onSelect={selectMode}
        onClose={() => setOpen(false)}
      />
    </div>
  )
}
