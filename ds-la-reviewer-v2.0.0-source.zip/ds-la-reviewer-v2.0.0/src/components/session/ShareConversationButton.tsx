import { useState } from 'react'
import { useTranslate } from '../../i18n/index.js'
import type { Session } from '../../services/chat/types.js'
import { exportConversationMarkdown } from '../../services/chat/exportConversation.js'
import { IconShareOutline16 } from '../base/icons.js'
import { IconButton } from '../base/IconButton.js'
import { showToast } from '../base/toastState.js'

/** 分享当前会话的全部可见消息为 Markdown，优先调用系统分享面板。 */
export const ShareConversationButton = ({
  session,
  size = 'm',
}: {
  session: Session
  size?: 'xs' | 'm' | 'xl'
}) => {
  const t = useTranslate()
  const [busy, setBusy] = useState(false)
  if (!session.messages.length) {
    return null
  }

  return (
    <IconButton
      icon={<IconShareOutline16 />}
      tooltip={t('shareConversation')}
      tooltipPlacement="bottom"
      size={size}
      disabled={busy}
      onClick={async () => {
        if (busy) {
          return
        }
        setBusy(true)
        try {
          const result = await exportConversationMarkdown(session)
          if (result === 'downloaded') {
            showToast({ key: 'shareConversationDownloaded' })
          }
        } catch {
          showToast({ key: 'shareConversationFailed', type: 'error' })
        } finally {
          setBusy(false)
        }
      }}
    />
  )
}
