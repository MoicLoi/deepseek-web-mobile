import type { ModeId } from '../../services/modes.js'
import { setDraftText } from '../../services/chat/drafts.js'
import styles from './PracticeStart.module.css'

const TYPES = [
  { label: '单选题', text: '我想练单选题。' },
  { label: '判断题', text: '我想练判断题。' },
  { label: '简答题', text: '我想练简答题。' },
  { label: '混合题', text: '我想练混合题。' },
]

/** 练习模式的第一问：先让用户选题型，默认参考书末例题。 */
export const PracticeStart = ({
  mode,
  sessionId,
}: {
  mode: ModeId
  sessionId: string | null
}) => {
  if (mode !== 'fragment' && mode !== 'mock') {
    return null
  }
  const mock = mode === 'mock'
  return (
    <section className={styles.card} aria-label="练习设置">
      <div className={styles.kicker}>{mock ? '模拟练习' : '片段练习'}</div>
      <div className={styles.question}>想练哪种题型？</div>
      <p className={styles.hint}>
        默认参考书末例题：{mock ? '单选题 6 道 + 判断题 4 道（共 100 分）' : '单选题、判断题'}。
      </p>
      <div className={styles.chips}>
        {TYPES.map((type) => (
          <button
            key={type.label}
            type="button"
            className={styles.chip}
            onClick={() => setDraftText(sessionId, type.text)}
          >
            {type.label}
          </button>
        ))}
        <button
          type="button"
          className={styles.primary}
          onClick={() =>
            setDraftText(
              sessionId,
              mock
                ? '按书末例题默认题型开始：6 道单选题 + 4 道判断题，共 100 分。'
                : '按书末例题默认题型开始：先来一道单选题。'
            )
          }
        >
          {mock ? '默认组卷' : '默认开始'}
        </button>
      </div>
    </section>
  )
}
