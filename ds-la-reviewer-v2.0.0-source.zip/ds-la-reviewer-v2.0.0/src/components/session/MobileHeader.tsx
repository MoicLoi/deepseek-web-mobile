import { IconMenuOutline20, IconNewChatOutline20 } from '../base/icons.js'
import { BrandMark } from '../base/BrandMark.js'
import { useTranslate } from '../../i18n/index.js'
import { newChat } from '../../services/chat/store.js'
import type { Session } from '../../services/chat/types.js'
import { IconButton } from '../base/IconButton.js'
import { openMobileSider } from '../sider/mobileSiderState.js'
import { ShareConversationButton } from './ShareConversationButton.js'
import styles from './MobileHeader.module.css'

/** 移动端顶栏：左侧菜单打开侧边栏；会话页再显示标题、分享与开启新对话 */
export const MobileHeader = ({ title, session }: { title?: string; session?: Session }) => {
  const t = useTranslate()
  return (
    <div className={styles.header}>
      <IconButton
        size="xl"
        tone="primary"
        icon={<IconMenuOutline20 />}
        aria-label={t('expandSiderbarButton')}
        onClick={openMobileSider}
      />
      {title === undefined ? (
        <div className={styles.brand}>
          <BrandMark size={22} />
          <span className={styles.brandName}>{t('appName')}</span>
        </div>
      ) : (
        <>
          <div className={styles.title}>{title}</div>
          <div className={styles.headerActions}>
            {session ? <ShareConversationButton session={session} size="xl" /> : null}
            <IconButton
              size="xl"
              tone="primary"
              icon={<IconNewChatOutline20 />}
              aria-label={t('newChat')}
              onClick={newChat}
            />
          </div>
        </>
      )}
    </div>
  )
}
