import { create } from 'zustand'
import { useSettings } from '../../services/settings.js'

/** 设置弹窗的分组：通用设置 / 模式与提示词 / 数据管理 */
export type SettingsSection = 'general' | 'prompts' | 'data'

/** 设置弹窗：侧边栏底部、没有 API Key 时的操作与 401 提示都可以打开；section 为打开时选中的分组 */
export const useSettingsDialog = create(() => ({
  open: false,
  section: 'general' as SettingsSection,
}))

export const openSettings = (section: SettingsSection) =>
  useSettingsDialog.setState({ open: true, section })

export const closeSettings = () => useSettingsDialog.setState({ open: false })

/**
 * 发送、上传等操作前的最后一道检查。
 * 没有 API Key 时由全屏接入页接管，不再打开设置弹窗。
 */
export const ensureApiKey = () => Boolean(useSettings.getState().apiKey)
