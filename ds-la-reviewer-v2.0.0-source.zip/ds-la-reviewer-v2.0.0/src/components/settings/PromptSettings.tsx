import { useState, type CSSProperties } from 'react'
import clsx from 'clsx'
import { useTranslate } from '../../i18n/index.js'
import {
  DEFAULT_MODE,
  MODE_IDS,
  MODE_PRESETS,
  getModePreset,
  resolveSystemPrompt,
  type ModeId,
} from '../../services/modes.js'
import {
  CONTEXT_ROUND_OPTIONS,
  resetPromptOverride,
  setContextRounds,
  setMode,
  setPromptOverride,
  useSettings,
} from '../../services/settings.js'
import { Button } from '../base/Button.js'
import { Select } from '../base/Select.js'
import { showToast } from '../base/toastState.js'
import { ModeIcon } from '../modes/ModeIcon.js'
import { contextRoundsLabel } from '../modes/contextRoundsLabel.js'
import styles from './PromptSettings.module.css'

/**
 * 模式与提示词设置：
 * - 新对话默认模式与上下文窗口；
 * - 逐模式预览、编辑、保存、恢复内置系统提示词。
 */
export const PromptSettings = () => {
  const t = useTranslate()
  const locale = useSettings((state) => state.locale)
  const defaultMode = useSettings((state) => state.mode)
  const contextRounds = useSettings((state) => state.contextRounds)
  const overrides = useSettings((state) => state.promptOverrides)
  const [editingMode, setEditingMode] = useState<ModeId>(defaultMode ?? DEFAULT_MODE)
  const [draft, setDraft] = useState(() =>
    resolveSystemPrompt(editingMode, locale, overrides[editingMode])
  )
  const [dirty, setDirty] = useState(false)
  const preset = getModePreset(editingMode)
  const customized = Boolean(overrides[editingMode]?.trim())

  const chooseMode = (mode: ModeId) => {
    setEditingMode(mode)
    setDraft(resolveSystemPrompt(mode, locale, overrides[mode]))
    setDirty(false)
  }

  const save = () => {
    if (!draft.trim()) {
      return
    }
    setPromptOverride(editingMode, draft)
    setDirty(false)
    showToast({ key: 'promptsSaved' })
  }

  const reset = () => {
    resetPromptOverride(editingMode)
    setDraft(resolveSystemPrompt(editingMode, locale, undefined))
    setDirty(false)
    showToast({ key: 'promptsResetDone' })
  }

  return (
    <div className={styles.container}>
      <div className={styles.intro}>
        <div className={styles.introTitle}>{t('settingDialogAsidePromptOptionLabel')}</div>
        <p className={styles.introDesc}>{t('modePickerDescription')}</p>
      </div>

      <div className={styles.row}>
        <div className={styles.rowText}>
          <div className={styles.label}>{t('promptsDefaultMode')}</div>
          <div className={styles.desc}>{t('promptsDefaultModeDescription')}</div>
        </div>
        <Select
          ariaLabel={t('promptsDefaultMode')}
          value={defaultMode}
          options={MODE_IDS.map((mode) => ({
            value: mode,
            label: t(MODE_PRESETS[mode].labelKey),
          }))}
          onChange={setMode}
        />
      </div>

      <div className={styles.row}>
        <div className={styles.rowText}>
          <div className={styles.label}>{t('modePickerContext')}</div>
          <div className={styles.desc}>{t('modePickerContextDescription')}</div>
        </div>
        <Select
          ariaLabel={t('modePickerContext')}
          value={String(contextRounds)}
          options={CONTEXT_ROUND_OPTIONS.map((value) => ({
            value: String(value),
            label: contextRoundsLabel(t, value),
          }))}
          onChange={(value) => setContextRounds(Number(value))}
        />
      </div>

      <div className={styles.editor}>
        <div className={styles.editorHeader}>
          <div className={styles.editorTitle}>
            <span
              className={styles.editorIcon}
              style={{ '--mode-accent': preset.accent } as CSSProperties}
            >
              <ModeIcon mode={editingMode} size={18} />
            </span>
            <span>{t('promptsEditorLabel')}</span>
          </div>
          <span className={clsx(styles.badge, customized && styles.badgeCustom)}>
            {t(customized ? 'promptsCustomized' : 'promptsBuiltin')}
          </span>
        </div>

        <div className={styles.modeTabs} role="tablist" aria-label={t('promptsModeLabel')}>
          {MODE_IDS.map((mode) => {
            const active = mode === editingMode
            return (
              <button
                key={mode}
                type="button"
                role="tab"
                aria-selected={active}
                className={clsx(styles.modeTab, active && styles.modeTabActive)}
                onClick={() => chooseMode(mode)}
              >
                {t(MODE_PRESETS[mode].labelKey)}
              </button>
            )
          })}
        </div>

        <textarea
          className={styles.textarea}
          aria-label={t('promptsEditorLabel')}
          value={draft}
          rows={7}
          spellCheck={false}
          onChange={(event) => {
            setDraft(event.target.value)
            setDirty(true)
          }}
        />
        <div className={styles.editorFooter}>
          <div className={styles.hint}>
            {t('promptsEditorDescription')}
            <br />
            {t('promptsContextInjected')} · {draft.length}
          </div>
          <div className={styles.actions}>
            <Button variant="outlined" size="s" onClick={reset} disabled={!customized && !dirty}>
              {t('promptsReset')}
            </Button>
            <Button size="s" onClick={save} disabled={!dirty || !draft.trim()}>
              {t('promptsSave')}
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
