import { useState } from 'react'
import { useTranslate } from '../../i18n/index.js'
import { IconDownloadOutline16 } from '../base/icons.js'
import { IconButton } from '../base/IconButton.js'
import { showToast } from '../base/toastState.js'
import { exportRoundMarkdown, type RoundExportInput } from '../../services/chat/exportRound.js'

/** 将当前这一轮问答导出为 .md，并通过系统分享面板发送到其他 App。 */
export const ExportMarkdownButton = ({ input }: { input: RoundExportInput }) => {
  const t = useTranslate()
  const [busy, setBusy] = useState(false)

  return (
    <IconButton
      icon={<IconDownloadOutline16 />}
      tooltip={t('exportMarkdown')}
      tooltipPlacement="bottom"
      disabled={busy}
      onClick={async () => {
        if (busy) {
          return
        }
        setBusy(true)
        try {
          const result = await exportRoundMarkdown(input)
          if (result === 'downloaded') {
            showToast({ key: 'exportMarkdownDownloaded' })
          }
        } catch {
          showToast({ key: 'exportMarkdownFailed', type: 'error' })
        } finally {
          setBusy(false)
        }
      }}
    />
  )
}
