/**
 * Android WebView 与旧版浏览器的少量运行时补丁。
 * SWC 会把语法降级到 Chrome 83，但不会补内置方法；这里只补项目实际用到的 ES2022 方法。
 */
const define = (target: object, key: string, value: unknown) => {
  if (!(key in target)) {
    Object.defineProperty(target, key, { value, configurable: true, writable: true })
  }
}

define(Object, 'hasOwn', (object: object, key: PropertyKey) =>
  Object.prototype.hasOwnProperty.call(object, key)
)

define(Array.prototype, 'at', function (this: unknown[], index: number) {
  const length = this.length
  const relative = Math.trunc(index) || 0
  const position = relative < 0 ? length + relative : relative
  return position < 0 || position >= length ? undefined : this[position]
})

define(Array.prototype, 'toReversed', function (this: unknown[]) {
  return [...this].reverse()
})

define(Array.prototype, 'toSorted', function (this: unknown[], compareFn?: (a: unknown, b: unknown) => number) {
  return [...this].sort(compareFn)
})
