export type BookSection = {
  title: string
  chapter: string
}

export type BookChapter = {
  title: string
  sections: BookSection[]
}

export type BookChunk = {
  chapter: string
  section: string
  subsection: string
  text: string
}

export type BookExample = {
  number: number
  type: 'single' | 'truefalse'
  question: string
  options: string[]
  answer: string
  explanation: string
}

export type BookData = {
  title: string
  subtitle: string
  chapters: BookChapter[]
  chunks: BookChunk[]
  examples: BookExample[]
}
