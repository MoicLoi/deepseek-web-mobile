import { Capacitor } from '@capacitor/core'
import { Directory, Encoding, Filesystem } from '@capacitor/filesystem'
import { Share } from '@capacitor/share'
import { translate } from '../../i18n/index.js'
import { getModePreset, type ModeId } from '../modes.js'
import type { ChatModel } from '../api/types.js'
import type { Source } from './view.js'

export type RoundExportInput = {
  /** 会话标题；为空时用首条提问截断 */
  sessionTitle: string
  mode: ModeId
  question: string
  answer: string
  files?: string[]
  model?: ChatModel | null
  createdAt?: number
  sources?: Pick<Source, 'url' | 'title' | 'siteName'>[]
}

export type RoundExportResult = 'shared' | 'downloaded' | 'cancelled'

const safeFilename = (value: string) => {
  const cleaned = value
    .replace(/[\\/:*?"<>|\r\n]/g, '-')
    .replace(/\s+/g, ' ')
    .trim()
    .slice(0, 42)
  return cleaned || 'DeepSeek 对话'
}

/** 生成稳定、可读、跨平台安全的 .md 文件名。 */
export const markdownFilename = (title: string, timestamp = Date.now()) => {
  const stamp = new Date(timestamp)
    .toISOString()
    .replace(/[-:]/g, '')
    .replace('T', '-')
    .slice(0, 13)
  return `${safeFilename(title)}-${stamp}.md`
}

const isCancelled = (error: unknown) => {
  const message = error instanceof Error ? error.message : String(error)
  return /cancel|abort/i.test(message)
}

const formatDate = (value?: number) => {
  if (!value) {
    return ''
  }
  return new Date(value).toLocaleString(undefined, {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  })
}

/** 把一轮问答整理成可迁移到其他笔记 / 编辑器应用的 Markdown。 */
export const buildRoundMarkdown = (input: RoundExportInput): string => {
  const title = input.sessionTitle.trim() || input.question.trim().slice(0, 42) || 'DeepSeek 对话'
  const mode = translate(getModePreset(input.mode).labelKey)
  const date = formatDate(input.createdAt)
  const meta = [`模式：${mode}`, `模型：${input.model ?? 'deepseek-flash'}`]
  if (date) {
    meta.push(`时间：${date}`)
  }

  const parts = [`# ${title}`, '', `> ${meta.join(' · ')}`, '', '## 用户', '', input.question || '（空消息）']
  if (input.files?.length) {
    parts.push('', `附件：${input.files.join('、')}`)
  }
  parts.push('', '## 助手', '', input.answer || '（无回答）')

  const sources = (input.sources ?? []).filter(
    (source, index, list) =>
      /^https?:\/\//i.test(source.url) && list.findIndex((item) => item.url === source.url) === index
  )
  if (sources.length) {
    parts.push('', '## 参考来源', '')
    sources.forEach((source, index) => {
      const suffix = source.siteName ? ` — ${source.siteName}` : ''
      parts.push(`${index + 1}. [${source.title || source.url}](${source.url})${suffix}`)
    })
  }

  return `${parts.join('\n')}\n`
}

export const exportRoundMarkdown = async (input: RoundExportInput): Promise<RoundExportResult> => {
  const markdown = buildRoundMarkdown(input)
  const filename = markdownFilename(input.sessionTitle || input.question, input.createdAt)
  return shareMarkdownFile(markdown, filename)
}

/** 通过原生分享 / Web Share 发送 Markdown；不可用时回退为下载。 */
export const shareMarkdownFile = async (
  markdown: string,
  filename: string
): Promise<RoundExportResult> => {
  const title = filename.replace(/\.md$/, '')

  if (Capacitor.isNativePlatform()) {
    const written = await Filesystem.writeFile({
      path: filename,
      data: markdown,
      directory: Directory.Cache,
      encoding: Encoding.UTF8,
    })
    try {
      await Share.share({
        title,
        text: markdown.slice(0, 240),
        files: [written.uri],
        dialogTitle: translate('exportMarkdown'),
      })
      return 'shared'
    } catch (error) {
      if (isCancelled(error)) {
        return 'cancelled'
      }
      throw error
    }
  }

  const file = new File([markdown], filename, { type: 'text/markdown;charset=utf-8' })
  if (typeof navigator.share === 'function') {
    try {
      if (!navigator.canShare || navigator.canShare({ files: [file] })) {
        await navigator.share({ files: [file], title })
        return 'shared'
      }
    } catch (error) {
      if (isCancelled(error)) {
        return 'cancelled'
      }
      // 分享失败时回退到下载，不吞掉用户的操作结果。
    }
  }

  const url = URL.createObjectURL(new Blob([markdown], { type: 'text/markdown;charset=utf-8' }))
  const anchor = document.createElement('a')
  anchor.href = url
  anchor.download = filename
  document.body.appendChild(anchor)
  anchor.click()
  anchor.remove()
  setTimeout(() => URL.revokeObjectURL(url), 10_000)
  return 'downloaded'
}
