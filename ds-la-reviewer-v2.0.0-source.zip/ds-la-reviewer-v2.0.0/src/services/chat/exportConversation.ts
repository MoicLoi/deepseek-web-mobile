import { translate } from '../../i18n/index.js'
import { getModePreset } from '../modes.js'
import { getVisibleMessages } from './branches.js'
import {
  markdownFilename,
  shareMarkdownFile,
  type RoundExportResult,
} from './exportRound.js'
import { getReplyText } from './reply.js'
import { getSessionMode, type AssistantMessage, type Session } from './types.js'

type SourceLink = {
  url: string
  title: string
  siteName: string
}

const collectSources = (message: AssistantMessage): SourceLink[] => {
  const seen = new Set<string>()
  const sources: SourceLink[] = []
  const add = (url: unknown, title: unknown, siteName: unknown = '') => {
    if (typeof url !== 'string' || !/^https?:\/\//i.test(url) || seen.has(url)) {
      return
    }
    seen.add(url)
    sources.push({
      url,
      title: typeof title === 'string' && title ? title : url,
      siteName: typeof siteName === 'string' ? siteName : '',
    })
  }

  for (const block of message.blocks) {
    if (block.type === 'text' && block.citations) {
      for (const citation of block.citations) {
        add(citation.url, citation.title)
      }
    } else if (block.type === 'web_search_tool_result' && Array.isArray(block.content)) {
      for (const item of block.content) {
        if (item.type === 'web_search_result') {
          add(item.url, item.title, item.site_name)
        }
      }
    } else if (block.type === 'web_fetch_tool_result') {
      const fetched = block.content
      if (fetched.type === 'web_fetch_result') {
        add(fetched.url, fetched.content.title)
      }
    }
  }
  return sources
}

const formatExportTime = () =>
  new Date().toLocaleString(undefined, {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  })

/** 导出当前会话中可见分支的全部问答；包含模式、模型、附件名与来源。 */
export const buildConversationMarkdown = (session: Session): string => {
  const messages = getVisibleMessages(session)
  const firstUser = messages.find((message) => message.role === 'user')
  const title =
    session.title.trim() ||
    (firstUser?.role === 'user' ? firstUser.content.trim().slice(0, 42) : '') ||
    'DeepSeek 对话'
  const mode = translate(getModePreset(getSessionMode(session)).labelKey)
  const assistantWithModel = messages.find(
    (message): message is AssistantMessage => message.role === 'assistant' && Boolean(message.model)
  )
  const model = assistantWithModel?.model ?? 'deepseek-flash'

  const parts = [
    `# ${title}`,
    '',
    `> 模式：${mode} · 模型：${model} · 导出时间：${formatExportTime()}`,
  ]

  if (!messages.length) {
    parts.push('', '（空对话）')
    return `${parts.join('\n')}\n`
  }

  let round = 0
  for (const message of messages) {
    if (message.role === 'user') {
      round += 1
      parts.push('', `## 第 ${round} 轮`, '', '### 用户', '', message.content || '（空消息）')
      if (message.files.length) {
        parts.push('', `附件：${message.files.map((file) => file.name).join('、')}`)
      }
      continue
    }

    const answer = getReplyText(message)
    parts.push(
      '',
      '### DeepSeek',
      '',
      answer || (message.error ? `> 错误：${message.error.message}` : '（无回答）')
    )
    const sources = collectSources(message)
    if (sources.length) {
      parts.push('', '#### 参考来源', '')
      sources.forEach((source, index) => {
        const suffix = source.siteName ? ` — ${source.siteName}` : ''
        parts.push(`${index + 1}. [${source.title}](${source.url})${suffix}`)
      })
    }
  }

  return `${parts.join('\n')}\n`
}

export const exportConversationMarkdown = (session: Session): Promise<RoundExportResult> => {
  const markdown = buildConversationMarkdown(session)
  const firstUser = getVisibleMessages(session).find((message) => message.role === 'user')
  const title =
    session.title.trim() ||
    (firstUser?.role === 'user' ? firstUser.content.trim() : '') ||
    'DeepSeek 对话'
  return shareMarkdownFile(markdown, markdownFilename(title))
}
