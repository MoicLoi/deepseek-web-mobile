import type { CapacitorConfig } from '@capacitor/cli'

/** Android 壳层：使用 https://localhost 作为稳定源，IndexedDB 与 localStorage 才能跨启动持久化。 */
const config: CapacitorConfig = {
  appId: 'com.deepseek.studio',
  appName: 'DeepSeek Studio',
  webDir: 'dist',
  server: {
    androidScheme: 'https',
  },
  android: {
    backgroundColor: '#ffffff',
    allowMixedContent: false,
  },
}

export default config
