#!/usr/bin/env python3
"""Build the GitHub release assets for deepseek-web-mobile.

Usage:
    python scripts/package_release.py

Requires:
    - dist/index.html (pnpm build)
    - android/app/build/outputs/apk/debug/app-debug.apk (gradle assembleDebug)
"""

from __future__ import annotations

import hashlib
import json
import shutil
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RELEASE = ROOT / "release"
META = json.loads((ROOT / "package.json").read_text(encoding="utf-8"))
NAME = META["name"]
VERSION = META["version"]
TAG = f"{NAME}-v{VERSION}"

SOURCE_ZIP = RELEASE / f"{TAG}-source.zip"
WEB_ZIP = RELEASE / f"{TAG}-web.zip"
IOS_ZIP = RELEASE / f"{TAG}-ios.zip"
APK = RELEASE / f"{TAG}-android-debug.apk"
FULL_ZIP = RELEASE / f"{TAG}-github-release.zip"

EXCLUDE_DIRS = {
    ".git",
    ".gradle",
    ".shots",
    "build",
    "dist",
    "node_modules",
    "release",
    "capacitor-cordova-android-plugins",
    "__pycache__",
}
EXCLUDE_FILES = {
    "local.properties",
    "capacitor.config.json",
    "capacitor.plugins.json",
}
EXCLUDE_PREFIXES = {
    "android/app/src/main/assets/public/",
}


def excluded(rel: Path) -> bool:
    text = rel.as_posix()
    if any(part in EXCLUDE_DIRS for part in rel.parts):
        return True
    if rel.name in EXCLUDE_FILES:
        return True
    if rel.suffix in {".apk", ".log"}:
        return True
    return any(text.startswith(prefix) for prefix in EXCLUDE_PREFIXES)


def add_bytes(zf: zipfile.ZipFile, arcname: str, data: bytes, executable: bool = False) -> None:
    info = zipfile.ZipInfo(arcname)
    info.compress_type = zipfile.ZIP_DEFLATED
    info.create_system = 3
    info.external_attr = (0o755 if executable else 0o644) << 16
    zf.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def add_file(zf: zipfile.ZipFile, path: Path, arcname: str, executable: bool = False) -> None:
    add_bytes(zf, arcname, path.read_bytes(), executable=executable)


def zip_tree(zf: zipfile.ZipFile, root: Path, prefix: str = "", skip=None) -> None:
    for path in sorted(root.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(root)
        if skip and skip(rel):
            continue
        arcname = f"{prefix}{rel.as_posix()}"
        add_file(zf, path, arcname, executable=rel.as_posix() in {"android/gradlew"})


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    RELEASE.mkdir(exist_ok=True)
    dist = ROOT / "dist"
    ios_html = ROOT / "ios" / "deepseek-studio.html"
    ios_readme = ROOT / "ios" / "README.md"
    apk_source = ROOT / "android" / "app" / "build" / "outputs" / "apk" / "debug" / "app-debug.apk"

    if not (dist / "index.html").exists():
        raise SystemExit("dist/index.html missing. Run: pnpm build")
    if not ios_html.exists():
        raise SystemExit("ios/deepseek-studio.html missing")
    if not apk_source.exists():
        raise SystemExit("Android APK missing. Run: cd android && gradle assembleDebug")

    for path in (SOURCE_ZIP, WEB_ZIP, IOS_ZIP, APK, FULL_ZIP):
        if path.exists():
            path.unlink()
    for name in ("SHA256SUMS.txt", "SHA256SUMS-all.txt"):
        path = RELEASE / name
        if path.exists():
            path.unlink()

    source_prefix = f"{TAG}/"
    with zipfile.ZipFile(SOURCE_ZIP, "w") as zf:
        zip_tree(zf, ROOT, prefix=source_prefix, skip=excluded)

    with zipfile.ZipFile(WEB_ZIP, "w") as zf:
        zip_tree(zf, dist)

    with zipfile.ZipFile(IOS_ZIP, "w") as zf:
        add_file(zf, ios_html, "index.html")
        add_file(zf, ios_readme, "README.md")
        add_file(zf, ROOT / "LICENSE", "LICENSE")

    shutil.copyfile(apk_source, APK)
    shutil.copyfile(ROOT / "docs" / "RELEASE_NOTES_v1.0.0.md", RELEASE / "RELEASE_NOTES.md")

    assets = [SOURCE_ZIP, WEB_ZIP, IOS_ZIP, APK]
    sums = [f"{sha256(path)}  {path.name}" for path in assets]
    (RELEASE / "SHA256SUMS.txt").write_text("\n".join(sums) + "\n", encoding="utf-8")

    with zipfile.ZipFile(FULL_ZIP, "w") as zf:
        zip_tree(zf, dist, prefix="web/")
        add_file(zf, ios_html, "ios/index.html")
        add_file(zf, ios_readme, "ios/README.md")
        add_file(zf, APK, f"android/{APK.name}")
        add_file(zf, SOURCE_ZIP, f"source/{SOURCE_ZIP.name}")
        add_file(zf, ROOT / "README.md", "README.md")
        add_file(zf, RELEASE / "RELEASE_NOTES.md", "RELEASE_NOTES.md")
        add_file(zf, RELEASE / "SHA256SUMS.txt", "SHA256SUMS.txt")
        add_file(zf, ROOT / "LICENSE", "LICENSE")

    all_sums = sums + [f"{sha256(FULL_ZIP)}  {FULL_ZIP.name}"]
    (RELEASE / "SHA256SUMS-all.txt").write_text("\n".join(all_sums) + "\n", encoding="utf-8")

    print(f"Release: {TAG}")
    for path in (SOURCE_ZIP, WEB_ZIP, IOS_ZIP, APK, FULL_ZIP):
        print(f"  {path.name:<58} {path.stat().st_size / 1024 / 1024:.2f} MiB")
    print(f"  {'SHA256SUMS.txt':<58} {(RELEASE / 'SHA256SUMS.txt').stat().st_size} B")
    print(f"  {'SHA256SUMS-all.txt':<58} {(RELEASE / 'SHA256SUMS-all.txt').stat().st_size} B")


if __name__ == "__main__":
    main()
