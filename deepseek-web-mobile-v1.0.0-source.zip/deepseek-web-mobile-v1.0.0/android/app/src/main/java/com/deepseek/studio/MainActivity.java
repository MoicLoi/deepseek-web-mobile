package com.deepseek.studio;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
