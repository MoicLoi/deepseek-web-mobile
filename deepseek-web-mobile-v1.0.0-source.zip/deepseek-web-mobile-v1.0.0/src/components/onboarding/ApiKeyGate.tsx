import { useTranslate } from '../../i18n/index.js'
import { useIsMobile } from '../../app/viewport.js'
import { useApiKeyForm } from '../settings/useApiKeyForm.js'
import { BrandMark } from '../base/BrandMark.js'
import { Button } from '../base/Button.js'
import styles from './ApiKeyGate.module.css'

const KEY_URL = 'https://platform.deepseek.com/api_keys'

/**
 * 全屏接入页：没有 DeepSeek API Key 时唯一可见的界面。
 * 不做「跳过」或游客模式；校验通过后才保存并进入聊天。
 */
export const ApiKeyGate = () => {
  const t = useTranslate()
  const isMobile = useIsMobile()
  const form = useApiKeyForm()

  return (
    <div className={styles.page}>
      <div className={styles.aurora} aria-hidden>
        <span className={styles.blobA} />
        <span className={styles.blobB} />
        <span className={styles.grid} />
      </div>

      <main className={styles.card}>
        <div className={styles.brand}>
          <BrandMark size={46} />
          <div className={styles.brandText}>
            <div className={styles.brandName}>DeepSeek Studio</div>
            <div className={styles.brandTagline}>{t('appTagline')}</div>
          </div>
        </div>

        <h1 className={styles.title}>{t('apiGateTitle')}</h1>
        <p className={styles.subtitle}>{t('apiGateSubtitle')}</p>
        <p className={styles.description}>{t('apiGateDescription')}</p>

        <div className={styles.requirement}>
          <span className={styles.requirementDot} aria-hidden />
          {t('apiGateRequirement')}
        </div>

        <form
          className={styles.form}
          onSubmit={(event) => {
            event.preventDefault()
            void form.submit()
          }}
        >
          <label className={styles.fieldLabel} htmlFor="deepseek-api-key">
            {t('apiGateKeyLabel')}
          </label>
          <div className={styles.inputWrap}>
            <input
              id="deepseek-api-key"
              className={styles.input}
              type="password"
              inputMode="text"
              autoComplete="off"
              spellCheck={false}
              autoFocus={!isMobile}
              placeholder={t('apiKeyPlaceholder')}
              value={form.value}
              onChange={(event) => form.setValue(event.target.value)}
            />
          </div>
          {form.error ? (
            <div className={styles.error} role="alert">
              {form.error}
            </div>
          ) : null}
          <Button
            type="submit"
            block
            className={styles.connect}
            disabled={!form.value.trim() || form.verifying}
          >
            {form.verifying ? t('apiGateConnecting') : t('apiGateConnect')}
          </Button>
        </form>

        <div className={styles.features}>
          <span>{t('apiGateFeatureModes')}</span>
          <span>{t('apiGateFeatureContext')}</span>
          <span>{t('apiGateFeaturePrivate')}</span>
        </div>

        <div className={styles.links}>
          <a href={KEY_URL} target="_blank" rel="noreferrer">
            {t('apiGateGetKey')}
          </a>
          <span className={styles.pricing}>{t('apiGatePricing')}</span>
        </div>

        <p className={styles.privacy}>{t('apiGatePrivacy')}</p>
      </main>

      <footer className={styles.footer}>{t('apiGateFooter')}</footer>
    </div>
  )
}
