import { useId } from 'react'

/**
 * 品牌图形：蓝色渐变圆角方块 + 一道白色浪线。
 * 只使用抽象几何，不复制官方商标；用于侧栏、顶栏和 API 接入页。
 */
export const BrandMark = ({ size = 28 }: { size?: number }) => {
  const id = useId().replace(/:/g, '')
  return (
    <svg
      className="brand-mark"
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={`${id}-bg`} x1="2" y1="1" x2="30" y2="31">
          <stop stopColor="#7C9CFF" />
          <stop offset="0.55" stopColor="#4D6BFE" />
          <stop offset="1" stopColor="#2947D8" />
        </linearGradient>
        <linearGradient id={`${id}-wave`} x1="7" y1="16" x2="25" y2="20">
          <stop stopColor="#FFFFFF" />
          <stop offset="1" stopColor="#E7EEFF" />
        </linearGradient>
      </defs>
      <rect x="1" y="1" width="30" height="30" rx="9" fill={`url(#${id}-bg)`} />
      <path
        d="M7.5 17.2c2.2-3.1 4.8-3.1 7 0s4.8 3.1 7 0"
        stroke={`url(#${id}-wave)`}
        strokeWidth="2.1"
        strokeLinecap="round"
      />
      <circle cx="23.4" cy="9.2" r="1.9" fill="#FFFFFF" fillOpacity="0.92" />
      <path
        d="M8.2 23.1c2.8 1.4 5.4 1.4 7.8.1s5.1-1.3 7.8.1"
        stroke="#FFFFFF"
        strokeOpacity="0.34"
        strokeWidth="1.35"
        strokeLinecap="round"
      />
    </svg>
  )
}
