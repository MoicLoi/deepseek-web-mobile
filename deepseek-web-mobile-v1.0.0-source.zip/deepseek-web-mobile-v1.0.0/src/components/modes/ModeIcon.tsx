import type { ModeId } from '../../services/modes.js'

/** 模式图标的统一 18px 线性风格；颜色继承 currentColor。 */
export const ModeIcon = ({ mode, size = 18 }: { mode: ModeId; size?: number }) => {
  const common = {
    width: size,
    height: size,
    viewBox: '0 0 20 20',
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 1.5,
    strokeLinecap: 'round' as const,
    strokeLinejoin: 'round' as const,
    'aria-hidden': true,
  }
  switch (mode) {
    case 'chat':
      return (
        <svg {...common}>
          <path d="M3.2 9.1c0-3 2.6-5.2 6-5.2s6 2.2 6 5.2-2.6 5.2-6 5.2c-.7 0-1.4-.1-2-.3L4.1 16l.8-3.1c-1.1-.9-1.7-2.2-1.7-3.8Z" />
          <path d="M7 8.7h6M7 11h3.8" />
        </svg>
      )
    case 'rp':
      return (
        <svg {...common}>
          <path d="M3.3 6.2c2.4-2.1 4.3-2.1 6.7 0 2.4-2.1 4.3-2.1 6.7 0-.4 5.5-2.7 8.9-6.7 10.2C6 15.1 3.7 11.7 3.3 6.2Z" />
          <path d="M6.5 8.5c.9.8 1.8.8 2.7 0M10.8 8.5c.9.8 1.8.8 2.7 0M7.6 12.1c1.6 1.2 3.2 1.2 4.8 0" />
        </svg>
      )
    case 'romance':
      return (
        <svg {...common}>
          <path d="M10 16.3S3.7 12.6 3.7 8.4c0-2 1.5-3.5 3.4-3.5 1.2 0 2.3.7 2.9 1.7.6-1 1.7-1.7 2.9-1.7 1.9 0 3.4 1.5 3.4 3.5 0 4.2-6.3 7.9-6.3 7.9Z" />
          <path d="M10 8.1v2.2M8.9 9.2h2.2" />
        </svg>
      )
    case 'novel':
      return (
        <svg {...common}>
          <path d="M10 5.2c-1.5-1.1-3.5-1.5-6.2-1.3v11c2.7-.2 4.7.2 6.2 1.3 1.5-1.1 3.5-1.5 6.2-1.3v-11c-2.7-.2-4.7.2-6.2 1.3Z" />
          <path d="M10 5.2v11M6.7 8.1c.9-.2 1.6-.1 2.2.1M6.7 10.4c.9-.2 1.6-.1 2.2.1" />
        </svg>
      )
    case 'lab':
      return (
        <svg {...common}>
          <path d="M8 3.5h4M8.7 3.5v4.1L5.2 14a2 2 0 0 0 1.7 3h6.2a2 2 0 0 0 1.7-3l-3.5-6.4V3.5" />
          <path d="M7 11.7h6M8.7 9.4h2.6" />
        </svg>
      )
    case 'research':
      return (
        <svg {...common}>
          <circle cx="8.7" cy="8.7" r="4.4" />
          <path d="m12 12 4.2 4.2M3.5 4.2V3.1h2.2M16.5 15.8v1.1h-2.2" />
        </svg>
      )
  }
}
