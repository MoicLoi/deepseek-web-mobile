import { create } from 'zustand'
import type { TtsVoice } from './api/speech.js'
import { normalizeLocation, type UserLocation } from './location.js'
import { DEFAULT_MODE, isModeId, type ModeId } from './modes.js'

export type Locale = 'zh-CN' | 'en-US'

/** 主题偏好；默认跟随系统 */
export type ThemePreference = 'light' | 'dark' | 'system'

/** 本机设置，存 localStorage：API Key、语言、主题、位置、朗读音色、深度思考与智能搜索开关、创作模式与提示词 */
type Settings = {
  apiKey: string | null
  locale: Locale
  themePreference: ThemePreference
  location: UserLocation | null
  ttsVoice: TtsVoice
  thinking: boolean
  search: boolean
  siderCollapsed: boolean
  /** 新对话默认模式；已有会话把自己的模式保存在 Session.mode */
  mode: ModeId
  /** 用户自定义的系统提示词；未设置的键使用内置预设 */
  promptOverrides: Partial<Record<ModeId, string>>
  /** 请求上下文保留的最近轮数；0 表示不截断 */
  contextRounds: number
}

const KEYS = {
  apiKey: 'chat-demo:api-key',
  locale: 'chat-demo:locale',
  location: 'chat-demo:location',
  themePreference: 'chat-demo:theme-preference',
  ttsVoice: 'chat-demo:tts-voice',
  thinking: 'chat-demo:thinking',
  search: 'chat-demo:search',
  siderCollapsed: 'chat-demo:sider-collapsed',
  mode: 'chat-demo:mode',
  promptOverrides: 'chat-demo:prompt-overrides',
  contextRounds: 'chat-demo:context-rounds',
} as const

export const CONTEXT_ROUND_OPTIONS = [6, 12, 24, 0] as const
export const DEFAULT_CONTEXT_ROUNDS = 12

const read = (key: string) => {
  try {
    return localStorage.getItem(key)
  } catch {
    return null
  }
}

const write = (key: string, value: string | null) => {
  try {
    if (value === null) {
      localStorage.removeItem(key)
    } else {
      localStorage.setItem(key, value)
    }
  } catch {
    // 存储不可用时只在内存中生效
  }
}

/** 位置选择模式跟随浏览器语言，与应用内选择的界面语言无关。 */
export const isChineseBrowser = (): boolean =>
  (typeof navigator === 'undefined' ? 'zh' : navigator.language).toLowerCase().startsWith('zh')

const initialLocale = (): Locale => {
  const saved = read(KEYS.locale)
  if (saved === 'zh-CN' || saved === 'en-US') {
    return saved
  }
  return isChineseBrowser() ? 'zh-CN' : 'en-US'
}

const initialLocation = (): UserLocation | null => {
  try {
    const location = normalizeLocation(JSON.parse(read(KEYS.location) ?? 'null'))
    if (!location) {
      return null
    }
    return isChineseBrowser()
      ? location.region === 'CN' && location.province
        ? location
        : null
      : { region: location.region }
  } catch {
    return null
  }
}

/** 未保存过时跟随系统 */
const initialThemePreference = (): ThemePreference => {
  const saved = read(KEYS.themePreference)
  return saved === 'light' || saved === 'dark' ? saved : 'system'
}

/** 未保存过时使用服务端默认音色 stella（海星） */
const initialTtsVoice = (): TtsVoice => (read(KEYS.ttsVoice) === 'tide' ? 'tide' : 'stella')

const initialMode = (): ModeId => {
  const saved = read(KEYS.mode)
  return isModeId(saved) ? saved : DEFAULT_MODE
}

const initialContextRounds = (): number => {
  const raw = read(KEYS.contextRounds)
  if (raw === null) {
    return DEFAULT_CONTEXT_ROUNDS
  }
  const saved = Number(raw)
  return (CONTEXT_ROUND_OPTIONS as readonly number[]).includes(saved)
    ? saved
    : DEFAULT_CONTEXT_ROUNDS
}

const initialPromptOverrides = (): Partial<Record<ModeId, string>> => {
  try {
    const parsed: unknown = JSON.parse(read(KEYS.promptOverrides) ?? '{}')
    if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed)) {
      return {}
    }
    return Object.fromEntries(
      Object.entries(parsed).filter(
        ([mode, value]) => isModeId(mode) && typeof value === 'string' && value.trim() !== ''
      )
    ) as Partial<Record<ModeId, string>>
  } catch {
    return {}
  }
}

export const useSettings = create<Settings>(() => ({
  apiKey: read(KEYS.apiKey),
  locale: initialLocale(),
  location: initialLocation(),
  themePreference: initialThemePreference(),
  ttsVoice: initialTtsVoice(),
  thinking: read(KEYS.thinking) === 'true',
  search: read(KEYS.search) === 'true',
  siderCollapsed: read(KEYS.siderCollapsed) === 'true',
  mode: initialMode(),
  promptOverrides: initialPromptOverrides(),
  contextRounds: initialContextRounds(),
}))

export const setLocale = (locale: Locale) => {
  write(KEYS.locale, locale)
  useSettings.setState({ locale })
}

export const setLocation = (value: UserLocation | null) => {
  const location = normalizeLocation(value)
  write(KEYS.location, location ? JSON.stringify(location) : null)
  useSettings.setState({ location })
}

export const setThemePreference = (themePreference: ThemePreference) => {
  write(KEYS.themePreference, themePreference)
  useSettings.setState({ themePreference })
}

export const setTtsVoice = (ttsVoice: TtsVoice) => {
  write(KEYS.ttsVoice, ttsVoice)
  useSettings.setState({ ttsVoice })
}

export const setApiKey = (apiKey: string | null) => {
  write(KEYS.apiKey, apiKey)
  useSettings.setState({ apiKey })
}

export const setThinking = (thinking: boolean) => {
  write(KEYS.thinking, String(thinking))
  useSettings.setState({ thinking })
}

export const setSearch = (search: boolean) => {
  write(KEYS.search, String(search))
  useSettings.setState({ search })
}

export const setSiderCollapsed = (siderCollapsed: boolean) => {
  write(KEYS.siderCollapsed, String(siderCollapsed))
  useSettings.setState({ siderCollapsed })
}

export const setMode = (mode: ModeId) => {
  write(KEYS.mode, mode)
  useSettings.setState({ mode })
}

export const setContextRounds = (contextRounds: number) => {
  const value = (CONTEXT_ROUND_OPTIONS as readonly number[]).includes(contextRounds)
    ? contextRounds
    : DEFAULT_CONTEXT_ROUNDS
  write(KEYS.contextRounds, String(value))
  useSettings.setState({ contextRounds: value })
}

const withoutMode = (
  overrides: Partial<Record<ModeId, string>>,
  mode: ModeId
): Partial<Record<ModeId, string>> =>
  Object.fromEntries(Object.entries(overrides).filter(([key]) => key !== mode)) as Partial<
    Record<ModeId, string>
  >

export const setPromptOverride = (mode: ModeId, prompt: string) => {
  const current = useSettings.getState().promptOverrides
  const next = prompt.trim()
    ? { ...current, [mode]: prompt }
    : withoutMode(current, mode)
  write(KEYS.promptOverrides, JSON.stringify(next))
  useSettings.setState({ promptOverrides: next })
}

export const resetPromptOverride = (mode: ModeId) => {
  const next = withoutMode(useSettings.getState().promptOverrides, mode)
  write(KEYS.promptOverrides, JSON.stringify(next))
  useSettings.setState({ promptOverrides: next })
}
