# deepseek-web-mobile

> 项目名：`deepseek-web-mobile`。应用显示名：DeepSeek Studio。一个强制接入 DeepSeek API 的多模式创作客户端。视觉与交互沿用 DeepSeek 官方 `chat-demo` 的风格，内置 6 种预设模式与面向上下文管理的精简系统提示词，并提供 Android WebView 壳层与 iOS 单页版。

> 非 DeepSeek 官方产品。本项目基于官方开源 demo（MIT）改造，不代表深度求索公司。

![接入页](docs/screenshots/onboarding.png)

## 核心特性

### 1. 必须接入 DeepSeek API

- 首次打开只显示全屏接入页，**没有游客模式、没有跳过按钮**。
- 输入 API Key 后先调用 `GET /models` 校验，通过才写入本机并进入应用。
- API 地址固定为 `https://api.deepseek.com`，不提供第三方中转配置。
- Key 只保存在本机 `localStorage`，不经过任何自建后端；对话内容直接发送至 DeepSeek API。
- 费用由用户自己的 DeepSeek 账户承担，应用不提供试用额度。

### 2. 六种内置模式

| 模式 | 定位 | 上下文管理重点 | 推荐工具 |
| --- | --- | --- | --- |
| 闲聊模式 | 日常问答、信息整理 | 最近 8 轮优先、冲突以最新表述为准 | 无 |
| RP 模式 | 沉浸式角色扮演 | 人设、关系、场景、道具、未完成事件作为记忆锚点 | 深度思考 |
| 恋爱模式 | RP 分支，慢热关系 | 关系阶段、称呼、承诺、误会、情绪线 | 深度思考 |
| 小说模式 | 续写、改稿、文风维护 | 人物表、时间线、伏笔、文风样本 | 无 |
| 实验记录模式 | 结构化实验记录 | 目的/材料/步骤/变量/对照/偏差跨轮追踪 | 深度思考 |
| 文献查找模式 | 检索与来源核验 | 研究问题、关键词、纳入排除标准、已读文献 | 强制联网搜索 |

模式是**会话级**属性：切换后从下一条消息生效，并自动成为下一次新对话的默认模式。侧栏会话标题前的彩色圆点表示该会话使用的模式。

![模式选择](docs/screenshots/modes.png)

### 3. 可切换、可编辑的系统提示词

- 每种模式内置一套**精简系统提示词**，只保留三部分：角色、输出约束、上下文规则。
- 「设置 → 模式与提示词」可以逐模式预览、编辑、保存、恢复内置版本。
- 自定义提示词同样会叠加当前上下文策略；内置长度约 200–400 字，建议自定义不超过 800 字。
- 上下文策略会随每轮请求动态追加，例如：
  `[上下文策略] 本轮只保留最近 12 轮对话，已省略 8 轮较早内容。不要臆测被省略的内容；缺少必要信息时先向用户确认。`

![提示词设置](docs/screenshots/prompts.png)

### 4. 上下文管理

- 默认只携带最近 **12 轮**对话，可在 6 / 12 / 24 轮或完整上下文中切换。
- 截断发生在客户端组装请求阶段：旧轮次不会发送，节省输入 Token，也减少长对话中的设定漂移。
- 历史附件只补传实际进入上下文的轮次。
- 系统提示词自动注入「不要臆测被省略内容」的约束。
- 继续生成、重新生成、编辑消息仍沿用现有分支与上下文逻辑。

### 5. 官方 demo 的完整能力

- 流式回复、深度思考、智能搜索、链接阅读、来源引用。
- 文件、图片上传，语音输入，朗读回答。
- Markdown、代码高亮、KaTeX、Mermaid。
- 多会话、自动标题、重命名、删除、消息分支、编辑与重新生成。
- 中英文、明暗主题、DeepSeek 历史对话 ZIP 导入导出。
- 移动端布局与桌面端布局自适应。

![欢迎页](docs/screenshots/welcome.png)

## 快速开始（Web）

环境：Node.js 22.12+、pnpm。

```bash
pnpm install
pnpm dev
```

打开 `http://localhost:8090`，在接入页填入 DeepSeek API Key。

生产构建：

```bash
pnpm build
# 输出在 dist/
```

`dist/` 可以直接部署到静态服务器。由于浏览器安全限制，语音输入需要 HTTPS（`localhost` 除外）。

## iOS 单页版

如果 iOS 用户不想安装 TestFlight / 原生包，可以直接托管单文件版：

- 文件：[ios/deepseek-studio.html](ios/deepseek-studio.html)
- 说明：[ios/README.md](ios/README.md)

它是零依赖、无需构建的单个 HTML，包含同样的强制 API 接入、六种模式、上下文窗口、提示词编辑、SSE 流式回复、深度思考、联网搜索、来源引用和深浅色主题。用 Safari 打开后「分享 → 添加到主屏幕」即可。

![iOS 版](docs/screenshots/ios-chat.png)

建议使用 HTTPS 托管；直接 `file://` 打开时，Safari 可能限制 `localStorage` 与跨域请求。单页版聚焦文本对话，不包含文件、语音和 Mermaid / KaTeX。

## Android

项目已包含 Capacitor Android 工程（`android/`）。

```bash
pnpm install
pnpm android:sync        # 构建 Web 资源并同步到 Android
pnpm android:open        # 用 Android Studio 打开
```

或直接构建 Debug APK：

```bash
pnpm android:apk
# android/app/build/outputs/apk/debug/app-debug.apk
```

要求：

- JDK 21
- Android SDK Platform 36、Build Tools 36
- Android WebView 83+（已在 API 30 / WebView 83 模拟器上验证；建议使用系统最新 WebView）
- Gradle 8.14.x（项目自带 wrapper；若网络无法访问 `services.gradle.org`，可使用本机 Gradle 8.14.3 运行等价命令）

Android 端使用 `https://localhost` 作为 WebView 源，确保 `localStorage` 与 IndexedDB 跨启动持久化。若使用自签或自定义 API 域名，需要自行处理 CORS；本项目不内置代理。

![Android](docs/screenshots/android.png)

Android 工程还包含品牌启动图、自适应图标、状态栏配色与录音权限。WebView 调试构建可通过 `adb forward` + `chrome://inspect` 检查页面。

## 项目结构

```text
src/
  app/                 应用布局、主题、视口处理
  components/
    onboarding/        API Key 全屏接入页
    modes/             模式条、模式选择器、模式图标
    chatInput/         输入框、附件、语音
    messages/          消息、回复、分支
    settings/          设置、API Key、模式与提示词
    sider/             侧栏、会话列表
    search/            搜索与引用
    markdown/          Markdown、代码、公式、图表
  services/
    modes.ts           六种模式、内置提示词、上下文策略
    settings.ts        API Key、模式、上下文轮数、提示词覆盖
    api/               DeepSeek Messages API 客户端与 SSE
    chat/              会话、分支、附件、请求组装
  i18n/                中英文文案
android/               Capacitor Android 壳层
```

## GitHub 发布包

项目名：`deepseek-web-mobile`。生成可上传到 GitHub Releases 的资产：

```bash
pnpm build
pnpm android:sync
cd android && gradle assembleDebug && cd ..
pnpm release:package
```

产物在 `release/`：

- `deepseek-web-mobile-v1.0.0-github-release.zip`：完整包（Web + iOS + APK + 源码）
- `deepseek-web-mobile-v1.0.0-source.zip`
- `deepseek-web-mobile-v1.0.0-web.zip`
- `deepseek-web-mobile-v1.0.0-ios.zip`
- `deepseek-web-mobile-v1.0.0-android-debug.apk`
- `SHA256SUMS.txt` / `SHA256SUMS-all.txt`

发布步骤见 [docs/GITHUB_RELEASE.md](docs/GITHUB_RELEASE.md)，Release 文案见 [docs/RELEASE_NOTES_v1.0.0.md](docs/RELEASE_NOTES_v1.0.0.md)。

## 数据与隐私

- API Key、模式、上下文设置保存在浏览器/设备本地。
- 会话与附件保存在 IndexedDB；导出历史时**不包含** API Key。
- 所有模型请求直接发送到 `https://api.deepseek.com`。
- 清除浏览器数据会同时删除本地会话和 API Key。
- 若面向公众提供服务，请自行完成内容安全、模型备案与 AI 生成内容标识等合规义务。

## 已知限制

- 本项目的「上下文管理」是客户端滑动窗口 + 提示词约束，不包含服务端摘要或向量记忆。
- 没有自建后端；依赖 DeepSeek API 的浏览器 CORS 策略与账户额度。
- Android 壳层未集成安全存储，API Key 仍保存在 WebView 的 localStorage。对安全要求更高的场景应改用 Android Keystore。
- 不支持非 DeepSeek 的 OpenAI 兼容端点。

## 许可与致谢

- 基于 [deepseek-ai/chat-demo](https://github.com/deepseek-ai/chat-demo)（MIT）改造，保留原始 `LICENSE`。
- DeepSeek 名称与相关商标归深度求索公司所有；本项目仅作技术演示，不暗示官方背书。
