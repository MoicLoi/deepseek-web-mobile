#!/usr/bin/env python3
"""Extract the user-provided 《实验动物学导论》 Markdown into the app knowledge pack."""

from __future__ import annotations

import html
import json
import re
from pathlib import Path

SOURCE = Path(r"D:\手机相册最新345张_20261125\ebook_work")
BOOK = SOURCE / "book.md"
EXERCISES = SOURCE / "transcript" / "part_15_exercises.md"
OUT = Path(__file__).resolve().parents[1] / "src" / "services" / "knowledge" / "la-book.json"
TS_OUT = OUT.with_suffix(".ts")


def clean_text(value: str) -> str:
    value = re.sub(r"<!--.*?-->", "", value, flags=re.S)
    value = re.sub(r"<del\b.*?</del>", "", value, flags=re.S | re.I)
    value = re.sub(r"<br\s*/?>", "\n", value, flags=re.I)
    value = re.sub(r"</t[dh]>", " | ", value, flags=re.I)
    value = re.sub(r"</tr>", "\n", value, flags=re.I)
    value = re.sub(r"<[^>]+>", "", value)
    value = html.unescape(value)
    value = value.replace("**", "").replace("__", "").replace("`", "")
    value = re.sub(r"[ \t]+", " ", value)
    value = re.sub(r"\n{3,}", "\n\n", value)
    return value.strip()


def parse_book() -> tuple[list[dict], list[dict]]:
    text = BOOK.read_text(encoding="utf-8")
    lines = text.splitlines()
    start = next((i for i, line in enumerate(lines) if line.startswith("# 前 言")), 0)
    chapters: list[dict] = []
    section_map: dict[str, dict] = {}
    chunks: list[dict] = []
    chapter = ""
    section = ""
    subsection = ""
    buffer: list[str] = []

    def add_chapter(title: str) -> None:
        entry = {"title": title, "sections": []}
        chapters.append(entry)
        section_map.clear()

    def add_section(title: str) -> None:
        entry = {"title": title, "chapter": chapter}
        if chapters:
            chapters[-1]["sections"].append(entry)
        section_map[title] = entry

    def flush() -> None:
        nonlocal buffer
        body = clean_text("\n".join(buffer)).strip()
        buffer = []
        if not body:
            return
        # keep chunks near 900 characters, preferring paragraph boundaries
        paragraphs = [part.strip() for part in re.split(r"\n\s*\n", body) if part.strip()]
        current: list[str] = []
        size = 0
        for paragraph in paragraphs:
            if len(paragraph) > 1600:
                for start_at in range(0, len(paragraph), 1200):
                    piece = paragraph[start_at : start_at + 1200].strip()
                    if piece:
                        chunks.append(
                            {
                                "chapter": chapter,
                                "section": section,
                                "subsection": subsection,
                                "text": piece,
                            }
                        )
                continue
            if current and size + len(paragraph) > 1100:
                chunks.append(
                    {
                        "chapter": chapter,
                        "section": section,
                        "subsection": subsection,
                        "text": "\n\n".join(current),
                    }
                )
                current = []
                size = 0
            current.append(paragraph)
            size += len(paragraph) + 2
        if current:
            chunks.append(
                {
                    "chapter": chapter,
                    "section": section,
                    "subsection": subsection,
                    "text": "\n\n".join(current),
                }
            )

    for line in lines[start:]:
        if line.startswith("# "):
            flush()
            chapter = clean_text(line[2:]).strip()
            section = ""
            subsection = ""
            if chapter and chapter != "附录七 例题":
                add_chapter(chapter)
            continue
        if line.startswith("## "):
            flush()
            section = clean_text(line[3:]).strip()
            subsection = ""
            if chapter and chapter != "附录七 例题":
                add_section(section)
            continue
        if line.startswith("### "):
            flush()
            subsection = clean_text(line[4:]).strip()
            buffer.append(f"### {subsection}")
            continue
        if line.startswith("#### "):
            flush()
            subsection = clean_text(line[5:]).strip()
            buffer.append(f"#### {subsection}")
            continue
        if chapter == "附录七 例题":
            continue
        buffer.append(line)
    flush()
    return chapters, chunks


def split_options(value: str) -> list[str]:
    value = value.strip()
    if not value:
        return []
    value = re.sub(r"\s+(?=[A-D]．)", "\n", value)
    return [clean_text(line) for line in value.splitlines() if clean_text(line)]


def parse_examples() -> list[dict]:
    text = EXERCISES.read_text(encoding="utf-8")
    examples: list[dict] = []
    for kind, heading in (("single", "## 单选题"), ("truefalse", "## 判断题")):
        if heading not in text:
            continue
        part = text.split(heading, 1)[1]
        part = re.split(r"\n## ", part, maxsplit=1)[0]
        blocks = re.split(r"\n(?=\*\*\d+．\*\*)", part)
        for block in blocks:
            match = re.search(r"\*\*(\d+)．\*\*\s*(.*?)(?=\n\n\*\*答案：\*\*)", block, re.S)
            if not match:
                continue
            number = int(match.group(1))
            question_block = match.group(2).strip()
            answer_match = re.search(r"\*\*答案：\*\*\s*([^\n]+)", block)
            explain_match = re.search(r"\*\*解析：\*\*\s*(.*)$", block, re.S)
            if not answer_match:
                continue
            question = question_block
            options: list[str] = []
            if kind == "single":
                option_lines = [
                    line for line in question_block.splitlines() if re.match(r"^[A-D]．", line.strip())
                ]
                if option_lines:
                    options = split_options("\n".join(option_lines))
                    question = question_block[: question_block.find(option_lines[0])].strip()
            examples.append(
                {
                    "number": number,
                    "type": kind,
                    "question": clean_text(question),
                    "options": options,
                    "answer": clean_text(answer_match.group(1)),
                    "explanation": clean_text(explain_match.group(1)) if explain_match else "",
                }
            )
    examples.sort(key=lambda item: item["number"])
    return examples


def fill_blank_bank() -> dict:
    questions = [
        ("____是指完成标准化、模式化，研究较为透彻的实验动物，包括小鼠、大鼠、斑马鱼、果蝇、线虫等。", "模式动物", "模式动物经过标准化和模式化，遗传背景与生物学特性清楚，便于比较研究。"),
        ("____是使用量最大、品种品系最多、研究最详尽的一类小型啮齿类实验动物。", "小鼠", "小鼠是使用量最大、品系最多、研究最详尽的实验动物。"),
        ("大鼠和小鼠的胃为单室胃，但分前胃和后胃，____胃富含肌肉和腺体，伸缩性强，不透明。", "后", "后胃富含肌肉和腺体，伸缩性强且不透明；前胃为无腺体部。"),
        ("____小鼠是我国特有的封闭群小鼠。", "昆明", "昆明小鼠（KM）是我国特有的封闭群小鼠，适应性强、繁殖力高。"),
        ("大鼠的环境相对湿度应控制在____。", "30%-70%", "大鼠适宜相对湿度为 30%～70%，湿度过高或过低都会影响健康与实验结果。"),
        ("在不影响实验结果判定的情况下，应尽早选择____，以缩短动物承受痛苦的时间。", "仁慈终点", "仁慈终点是在实验目标仍可达成时提前结束动物痛苦；安乐死是生命终止方式，不能替代终点判断。"),
        ("实验动物安乐死用注射药物优先选择的注射方式是____。", "静脉注射", "安乐死注射给药优先选择静脉注射，吸收快、剂量准确、动物痛苦小。"),
        ("不同品种的动物，选择其某一生物学特性，经过一定的繁殖方式和培育，使某一特性得到强化以后可以稳定地遗传下来，就成为一个____。", "品系", "品系是具有稳定遗传特征、来源清楚的动物群体。"),
        ("实验动物在产前准备及孕育后代过程中应选择____饲料。", "繁殖", "繁殖饲料针对妊娠、哺乳和幼仔发育的营养需求配制。"),
        ("____是研究实验性接触性变态反应的最佳动物。", "豚鼠", "豚鼠皮肤对致敏原反应明显，是研究接触性变态反应的常用动物。"),
    ]
    return {
        "title": "新题库 · 填空题（10题，100分）",
        "questions": [
            {"number": index, "question": question, "answer": answer, "explanation": explanation}
            for index, (question, answer, explanation) in enumerate(questions, 1)
        ],
    }


def main() -> None:
    chapters, chunks = parse_book()
    examples = parse_examples()
    data = {
        "title": "实验动物学导论",
        "subtitle": "DS-LA-reviewer · 实验动物学导论复习助手",
        "chapters": chapters,
        "chunks": chunks,
        "examples": examples,
        "fillBlankBank": fill_blank_bank(),
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    OUT.write_text(payload, encoding="utf-8")
    TS_OUT.write_text(
        "import type { BookData } from './types.js'\n\n"
        "export const LA_BOOK: BookData = "
        + payload
        + "\n",
        encoding="utf-8",
    )
    print(f"chapters={len(chapters)} chunks={len(chunks)} examples={len(examples)}")
    print(f"bytes={OUT.stat().st_size:,} ts={TS_OUT.stat().st_size:,}")
    print("example types:", [(item["number"], item["type"], item["answer"]) for item in examples])


if __name__ == "__main__":
    main()
