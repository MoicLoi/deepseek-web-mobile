import { LA_BOOK } from './la-book.js'
import type { BookChunk, BookExample, FillBlankBank } from './types.js'

export type {
  BookChapter,
  BookChunk,
  BookExample,
  BookSection,
  FillBlankBank,
  FillBlankQuestion,
} from './types.js'
export { LA_BOOK }

export const BOOK_TITLE = LA_BOOK.title
export const BOOK_SUBTITLE = LA_BOOK.subtitle
export const BOOK_EXAMPLES: BookExample[] = LA_BOOK.examples
export const BOOK_CHAPTERS = LA_BOOK.chapters
export const FILL_BLANK_BANK: FillBlankBank = LA_BOOK.fillBlankBank

const STOP_TERMS = new Set([
  '什么',
  '怎么',
  '为什',
  '如何',
  '哪些',
  '可以',
  '是否',
  '介绍',
  '一下',
  '总结',
  '区别',
  '作用',
  '的是',
  '有哪',
  '在什',
  '么环',
  '请问',
  '帮我',
  '开始',
  '默认',
])

const normalize = (value: string) =>
  value
    .toLowerCase()
    .replace(/[^\p{Script=Han}a-z0-9]+/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim()

/** 中文用 2~4 字组合召回，英文/数字按词召回。 */
const queryTerms = (query: string): string[] => {
  const terms = new Set<string>()
  for (const part of normalize(query).split(' ')) {
    if (!part) {
      continue
    }
    if (/\p{Script=Han}/u.test(part)) {
      if (part.length <= 8) {
        terms.add(part)
      }
      for (let size = 2; size <= Math.min(4, part.length); size += 1) {
        for (let index = 0; index + size <= part.length; index += 1) {
          const term = part.slice(index, index + size)
          if (!STOP_TERMS.has(term)) {
            terms.add(term)
          }
        }
      }
    } else if (part.length >= 2) {
      terms.add(part)
    }
  }
  return [...terms].filter((term) => term.length >= 2).slice(0, 40)
}

const countOccurrences = (text: string, term: string) => {
  let count = 0
  let index = text.indexOf(term)
  while (index !== -1 && count < 4) {
    count += 1
    index = text.indexOf(term, index + term.length)
  }
  return count
}

const scoreChunk = (chunk: BookChunk, terms: string[]) => {
  const body = `${chunk.chapter} ${chunk.section} ${chunk.subsection} ${chunk.text}`.toLowerCase()
  const headline = `${chunk.chapter} ${chunk.section} ${chunk.subsection}`.toLowerCase()
  let score = 0
  for (const term of terms) {
    const inBody = countOccurrences(body, term)
    if (inBody) {
      score += inBody * (term.length >= 3 ? 2 : 1)
    }
    if (headline.includes(term)) {
      score += 3
    }
  }
  return score
}

export const searchBook = (query: string, limit = 5): BookChunk[] => {
  const terms = queryTerms(query)
  if (!terms.length) {
    return []
  }
  return LA_BOOK.chunks
    .map((chunk) => ({ chunk, score: scoreChunk(chunk, terms) }))
    .filter((item) => item.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, limit)
    .map((item) => item.chunk)
}

export const outlineContext = (maxChars = 3200) => {
  const lines = ['[教材目录]']
  for (const chapter of LA_BOOK.chapters) {
    lines.push(chapter.title)
    for (const section of chapter.sections) {
      lines.push(`  ${section.title}`)
    }
  }
  const text = lines.join('\n')
  return text.slice(0, maxChars)
}

export const examplesContext = (maxChars = 5200) => {
  const blocks = BOOK_EXAMPLES.map((example) => {
    const options = example.options.length ? `\n${example.options.join('\n')}` : ''
    return `【${example.type === 'single' ? '单选题' : '判断题'} ${example.number}】${example.question}${options}\n答案：${example.answer}\n解析：${example.explanation}`
  })
  return `[书末例题：默认题型参考]\n${blocks.join('\n\n')}`.slice(0, maxChars)
}

export const fillBlankContext = (maxChars = 4200) => {
  const blocks = FILL_BLANK_BANK.questions.map(
    (question) =>
      `${question.number}. ${question.question}\n答案：${question.answer}\n解析：${question.explanation}`
  )
  return `[${FILL_BLANK_BANK.title}]\n${blocks.join('\n\n')}`.slice(0, maxChars)
}

export const knowledgeContext = (query: string, maxChars = 6800) => {
  const hits = searchBook(query, 5)
  if (!hits.length) {
    return ''
  }
  const parts = ['[教材检索片段 · 实验动物学导论]']
  for (const hit of hits) {
    const location = [hit.chapter, hit.section, hit.subsection].filter(Boolean).join(' / ')
    parts.push(`【${location}】\n${hit.text}`)
  }
  return parts.join('\n\n').slice(0, maxChars)
}

/**
 * 为四种模式组装教材上下文：
 * - 查阅：优先命中片段，不足时给目录；
 * - 出题/练习：附书末例题与目录，命中片段作为出题素材。
 */
export const buildKnowledgeContext = (
  mode: 'reference' | 'quiz' | 'fragment' | 'mock',
  query: string,
  firstTurn = true
) => {
  const hits = knowledgeContext(query)
  const blocks: string[] = []
  if (hits) {
    blocks.push(hits)
  }
  if (mode === 'reference' && !hits) {
    blocks.push(outlineContext())
  }
  if (mode === 'quiz' || mode === 'fragment' || mode === 'mock') {
    if (!hits) {
      blocks.push(outlineContext(2200))
    }
    if (/填空|新题库/.test(query)) {
      blocks.push(fillBlankContext())
    } else if (mode === 'quiz' || firstTurn) {
      blocks.push(examplesContext(mode === 'mock' ? 6200 : 4200))
    }
  }
  return blocks.join('\n\n').slice(0, 7600)
}

export const defaultQuestionTypes = '单选题 6 道 + 判断题 4 道（共 100 分）'

export const defaultPracticePrompt =
  '想练哪种题型？可选：单选题、判断题、简答题、混合题。默认按书末例题：单选题 6 道 + 判断题 4 道（共 100 分）。'
