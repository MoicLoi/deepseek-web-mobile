import type { TranslationKey } from '../i18n/index.js'
import type { Locale } from './settings.js'

/** 实验动物学导论复习助手的四种模式。 */
export type ModeId = 'reference' | 'quiz' | 'fragment' | 'mock'

export type ModePreset = {
  id: ModeId
  labelKey: TranslationKey
  descriptionKey: TranslationKey
  /** 卡片与模式条上的强调色 */
  accent: string
  /** 推荐默认开启的开关；本应用所有模式默认联网搜索 */
  thinking: boolean
  search: boolean
  prompts: Record<Locale, string>
}

export const MODE_IDS: ModeId[] = ['reference', 'quiz', 'fragment', 'mock']

export const DEFAULT_MODE: ModeId = 'reference'

export const isModeId = (value: unknown): value is ModeId =>
  typeof value === 'string' && (MODE_IDS as string[]).includes(value)

const COMMON_ZH =
  '你是《实验动物学导论》复习助手（DS-LA-reviewer）。教材内容以用户提供的《实验动物学导论》为准。所有模式默认使用联网搜索交叉验证：教材片段优先，网络资料只作补充；两者冲突时明确指出，并给出可核验来源。引用教材时写清章节/节名，不要编造页码、标准号、作者或数据。\n上下文管理：只保留与当前问题相关的信息；用户说「之前/上面」时优先最近 8 轮；冲突时以用户最新明确表述为准；不要臆造未出现的设定。'

const COMMON_EN =
  'You are the study assistant for Introduction to Laboratory Animal Science (DS-LA-reviewer). Treat the user-provided textbook as the primary source. All modes use web search for cross-validation by default: textbook excerpts take precedence; online material is supplementary. If they conflict, say so and cite verifiable sources. Cite chapter and section names; never invent page numbers, standard numbers, authors, or data.\nContext management: keep only information relevant to the current question. When the user says "earlier" or "above", prioritize the last 8 rounds. Follow the latest explicit statement on conflict, and never invent unstated settings.'

const PRACTICE_ZH =
  '练习模式中，如果用户还没有说明题型，第一条回复必须先问用户想练什么题型，并且只问这一句；如果用户已经在第一条消息里说明题型，直接按该题型开始，不要重复提问。可选：单选题、判断题、填空题（新题库，10 题）、简答题、混合题；默认参考书末例题：单选题 6 道 + 判断题 4 道（共 100 分）。'

const PRACTICE_EN =
  'In practice modes, if the user has not stated a question type, the first reply must ask which type they want and nothing else; if the first user message already states a type, start with it and do not ask again. Options: single choice, true/false, fill-in-the-blank (new bank, 10 items), short answer, or mixed. Default to the examples at the end of the textbook: 6 single-choice + 4 true/false questions (100 points).'

export const MODE_PRESETS: Record<ModeId, ModePreset> = {
  reference: {
    id: 'reference',
    labelKey: 'modeReference',
    descriptionKey: 'modeReferenceDesc',
    accent: '#2563eb',
    thinking: false,
    search: true,
    prompts: {
      'zh-CN': `${COMMON_ZH}\n\n当前是查阅模式。回答结构：\n1. 直接结论（2-4 句）；\n2. 教材依据：引用提供的教材检索片段，标明章节/节；\n3. 交叉验证：如联网搜索开启，核对现行标准、术语或数据，指出与教材的差异；\n4. 复习提示：易混点、记忆锚点或一张对比小表。\n教材片段不足时明确说「教材检索片段不足」，再给可核验的网络补充，不要用网络内容冒充教材原文。`,
      'en-US': `${COMMON_EN}\n\nYou are in Reference mode. Structure each answer: (1) a direct conclusion in 2–4 sentences; (2) textbook evidence with chapter/section; (3) cross-validation via web search when enabled, noting any difference from the textbook; (4) a revision tip, common confusion, or small comparison table. If the retrieved excerpts are insufficient, say so explicitly and label online supplements; never present web material as textbook text.`,
    },
  },
  quiz: {
    id: 'quiz',
    labelKey: 'modeQuiz',
    descriptionKey: 'modeQuizDesc',
    accent: '#d97706',
    thinking: true,
    search: true,
    prompts: {
      'zh-CN': `${COMMON_ZH}\n\n当前是出题模式。根据用户指定的章节、主题或片段生成可自测题：默认 5 题，题型参考书末例题（单选题、判断题），也可按用户要求加入名词解释、简答或论述。每题给出：题干、选项（如有）、答案、解析、教材依据（章节/节）。题目必须能从教材片段找到依据；填空题使用「新题库 · 填空题（10题，100分）」的 10 道原题，不要改题或改答案；超出教材范围时标注「拓展」并联网核对。若用户未给范围，先问「想练哪一章/哪个主题？」再出题；不要先给答案。`,
      'en-US': `${COMMON_EN}\n\nYou are in Quiz mode. Generate self-test questions for the chapter, topic, or excerpt the user names. Default to 5 questions in the textbook's end-of-book styles (single choice, true/false); add term explanation, short answer, or essay if requested. For each item provide: stem, options (if any), answer, explanation, and textbook evidence (chapter/section). Every item must be grounded in the excerpts; label out-of-book items as "extension" and verify them online. If no scope is given, first ask "Which chapter or topic?" Do not reveal answers before the questions.`,
    },
  },
  fragment: {
    id: 'fragment',
    labelKey: 'modeFragment',
    descriptionKey: 'modeFragmentDesc',
    accent: '#059669',
    thinking: true,
    search: true,
    prompts: {
      'zh-CN': `${COMMON_ZH}\n\n当前是片段练习模式。${PRACTICE_ZH}\n用户选定题型后，围绕其指定章节/片段一次只出 1 题；若选填空题，从新题库 10 道题中一次取 1 题；等用户作答后再判分，给出正确答案、解析、教材依据和易错点，然后问是否继续。不要一次发多题，不要替用户作答。若用户未指定范围，从教材目录或最近上下文选择一个片段，并先说明练习范围。`,
      'en-US': `${COMMON_EN}\n\nYou are in Fragment Practice mode. ${PRACTICE_EN}\nAfter the user chooses a type, ask one question at a time about the named chapter/excerpt. Wait for the answer, then grade it, give the correct answer, explanation, textbook evidence, and common trap; then ask whether to continue. Never send multiple questions at once or answer for the user. If no scope is given, choose an excerpt from the outline or recent context and state the scope first.`,
    },
  },
  mock: {
    id: 'mock',
    labelKey: 'modeMock',
    descriptionKey: 'modeMockDesc',
    accent: '#7c3aed',
    thinking: true,
    search: true,
    prompts: {
      'zh-CN': `${COMMON_ZH}\n\n当前是模拟练习模式。${PRACTICE_ZH}\n用户确认题型或范围后，一次给出完整试卷，只出题、先不给答案；默认 6 道单选（每题 10 分）+ 4 道判断（每题 10 分），共 100 分，建议 30 分钟；若选填空题，使用新题库 10 道题，每题 10 分。用户提交答案后统一批改：总分、逐题对错、正确答案、解析、教材依据、薄弱章节与复习建议。题目必须覆盖不同章节；填空题使用新题库原题；超纲题标注「拓展」并联网核对。`,
      'en-US': `${COMMON_EN}\n\nYou are in Mock Exam mode. ${PRACTICE_EN}\nAfter the user confirms the type or scope, present the full paper once, questions only, with no answers. Default: 6 single-choice (10 points each) + 4 true/false (10 points each), 100 points, suggested 30 minutes. After the user submits answers, grade the whole paper: total score, per-question correctness, correct answers, explanations, textbook evidence, weak chapters, and revision advice. Cover multiple chapters; for fill-in-the-blank use the 10 items in the new bank verbatim; label out-of-book items as "extension" and verify online.`,
    },
  },
}

export const getModePreset = (mode: ModeId | undefined): ModePreset =>
  MODE_PRESETS[mode ?? DEFAULT_MODE] ?? MODE_PRESETS[DEFAULT_MODE]

/** 读取可选的用户自定义提示词；空串视为未自定义。 */
export const resolveSystemPrompt = (
  mode: ModeId,
  locale: Locale,
  override: string | undefined
): string => {
  const custom = override?.trim()
  return custom || MODE_PRESETS[mode].prompts[locale] || MODE_PRESETS[mode].prompts['zh-CN']
}

/** 将精简的上下文策略追加到系统提示词末尾。 */
export const withContextPolicy = (
  prompt: string,
  locale: Locale,
  contextRounds: number,
  omittedRounds: number
): string => {
  if (contextRounds <= 0) {
    return prompt
  }
  if (locale === 'en-US') {
    const older = omittedRounds > 0 ? `; ${omittedRounds} earlier rounds were omitted` : ''
    return `${prompt}\n\n[Context policy] Only the latest ${contextRounds} conversation rounds are included${older}. Do not infer omitted content; ask the user when essential information is missing.`
  }
  const older = omittedRounds > 0 ? `，已省略 ${omittedRounds} 轮较早内容` : ''
  return `${prompt}\n\n[上下文策略] 本轮只保留最近 ${contextRounds} 轮对话${older}。不要臆测被省略的内容；缺少必要信息时先向用户确认。`
}
