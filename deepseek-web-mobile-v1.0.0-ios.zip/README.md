# DeepSeek Studio · iOS 单页版

`deepseek-studio.html` 是一个**完全独立、零依赖、无需构建**的单文件应用，面向 iPhone / iPad 的 Safari。它保留了主项目的核心体验：

- 强制接入 DeepSeek API，没有游客模式或试用额度
- 闲聊 / RP / 恋爱 / 小说 / 实验记录 / 文献查找 六种模式
- 精简系统提示词，可在设置中逐模式编辑、恢复内置
- 最近 6 / 12 / 24 轮或完整上下文
- SSE 流式回复、深度思考、智能搜索、来源引用
- 多会话、本地保存、浅色 / 深色 / 跟随系统
- 适配 iOS 安全区、软键盘与 `visualViewport`

## 使用

### 方式一：托管（推荐）

把 `deepseek-studio.html` 放到任意 **HTTPS** 静态空间（GitHub Pages、Cloudflare Pages、自己的服务器均可），然后用 Safari 打开。

在 Safari 中点击「分享 → 添加到主屏幕」，即可获得接近原生 App 的全屏体验。

### 方式二：本地预览

```bash
cd ios
python -m http.server 8092
```

浏览器打开 `http://127.0.0.1:8092/deepseek-studio.html`。

> 直接双击 `file://` 打开时，Safari 可能限制 `localStorage` 与跨域请求，因此不推荐；需要持久化和 API 请求时请使用 HTTPS 托管。

## 接入 API

1. 打开页面后输入 DeepSeek API Key。
2. 页面会调用 `GET https://api.deepseek.com/models` 校验，通过后保存在当前站点的 `localStorage`。
3. 对话请求直接发往 `https://api.deepseek.com/anthropic/v1/messages`，模型为 `deepseek-flash`。
4. 费用由你的 DeepSeek 账户承担。

设置中可以更换或断开 API Key；断开后立即回到全屏接入页，本地对话记录保留。

## 与完整客户端的差异

单页版聚焦**文本对话**，以便保持单文件、无依赖：

- 不支持文件 / 图片上传、语音输入、朗读。
- Markdown 支持标题、列表、粗体、斜体、行内代码、代码块、引用和链接；没有 Mermaid / KaTeX 渲染。
- 会话只在当前浏览器保存，换浏览器或清理网站数据会丢失。
- 没有服务端摘要或向量记忆；上下文管理是客户端滑动窗口 + 提示词约束。
- 依赖 DeepSeek API 的浏览器 CORS 策略。若企业网络或代理拦截，需要自行处理。

## 兼容性

- iOS / iPadOS 15+ 建议；需要支持 `fetch` 流式读取的 Safari。
- 已在 iPhone 尺寸的 Chromium 移动模拟器中验证接入页、模式选择、设置、SSE 流式渲染、Markdown 与来源卡片。
- 真机验证时，请确认 API Key 有可用余额，并在 Safari 中允许跨站请求。

## 隐私

- API Key、对话、模式与提示词设置只保存在当前站点的 `localStorage`。
- 没有自建后端，不会把 Key 发送给 DeepSeek 以外的第三方。
- 发送消息时，消息内容会直接提交给 DeepSeek API。

本项目为非官方客户端，与深度求索公司无隶属关系。
